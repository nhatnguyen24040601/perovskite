import { BookOpen, ChevronLeft, ChevronRight, CircleHelp, Pause, Play, RotateCcw } from "lucide-react";
import { useEffect } from "react";
import { chapters, getLesson, lessons, QUIZ } from "@/lib/sim/content";
import {
  diffusionUm,
  egFromHalide,
  pce,
  phaseFromTemp,
  photonEnergy,
  sqEfficiency,
  tolerance,
  vocFromPlqy,
  ION,
} from "@/lib/sim/physics";
import { useSim } from "@/lib/sim/store";
import type { Cation } from "@/lib/sim/types";
import type { ControlKind } from "@/lib/sim/content";
import { Stage } from "./three/Stage";

function Mark() {
  return (
    <svg className="brand-mark" viewBox="0 0 36 36" aria-hidden="true">
      <rect width="36" height="36" rx="8" fill="#151c24" />
      <path d="M18 5 30 18 18 31 6 18Z" fill="none" stroke="#e4a23a" strokeWidth="1.6" />
      <path d="M6 18h24M18 5l7 13-7 13-7-13Z" fill="none" stroke="#6d4bd6" strokeWidth="1.2" />
      <circle cx="18" cy="18" r="2.2" fill="#c5ccd6" />
    </svg>
  );
}

export function SimApp() {
  const lessonId = useSim((s) => s.lessonId);
  const step = useSim((s) => s.step);
  const explain = useSim((s) => s.explain);
  const playing = useSim((s) => s.playing);
  const help = useSim((s) => s.help);
  const query = useSim((s) => s.query);
  const inspect = useSim((s) => s.inspect);
  const quiz = useSim((s) => s.quiz);
  const lesson = getLesson(lessonId);
  const current = lesson.steps[step] ?? lesson.steps[0]!;
  const setLesson = useSim((s) => s.setLesson);
  const setStep = useSim((s) => s.setStep);
  const next = useSim((s) => s.next);
  const prev = useSim((s) => s.prev);
  const togglePlay = useSim((s) => s.togglePlay);
  const toggleExplain = useSim((s) => s.toggleExplain);
  const toggleRotate = useSim((s) => s.toggleRotate);
  const autoRotate = useSim((s) => s.autoRotate);
  const bumpReplay = useSim((s) => s.bumpReplay);
  const toggleHelp = useSim((s) => s.toggleHelp);
  const answerQuiz = useSim((s) => s.answerQuiz);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("perovskite-lab-v1");
      if (!raw) return;
      const saved = JSON.parse(raw) as { lessonId?: string; explain?: boolean };
      if (saved.lessonId && lessons.some((l) => l.id === saved.lessonId)) {
        useSim.getState().setLesson(saved.lessonId);
      }
      if (typeof saved.explain === "boolean") {
        const id = useSim.getState().lessonId;
        const force = id === "glossary" || id === "refs" || id === "quiz";
        useSim.setState({ explain: force ? true : saved.explain });
      }
    } catch {
      /* ignore broken saves */
    }
  }, []);

  useEffect(() => {
    return useSim.subscribe((s) => {
      localStorage.setItem(
        "perovskite-lab-v1",
        JSON.stringify({ lessonId: s.lessonId, explain: s.explain }),
      );
    });
  }, []);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      useSim.setState({ autoRotate: false, playing: false });
    }
  }, []);

  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => useSim.getState().next(), 8000);
    return () => window.clearInterval(id);
  }, [playing, lessonId, step]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
      if (e.key === " ") {
        e.preventDefault();
        togglePlay();
      }
      if (e.key === "e" || e.key === "E") toggleExplain();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev, toggleExplain, togglePlay]);

  const filtered = lesson.steps
    .map((s, i) => ({ s, i }))
    .filter(({ s }) => {
      if (!query.trim()) return true;
      const hay = `${s.title} ${s.body}`.toLowerCase();
      return hay.includes(query.trim().toLowerCase());
    });

  const quizItem = lesson.id === "quiz" ? QUIZ[step] : undefined;
  const quizScore = QUIZ.reduce((n, q, i) => n + (quiz[i] === q.answer ? 1 : 0), 0);

  return (
    <div className={explain ? "app" : "app explain-off"}>
      <header className="topbar">
        <div className="brand">
          <Mark />
          <div>
            <div className="brand-name">Perovskite Lab</div>
            <div className="brand-sub">Halide · ABX₃ · pin mặt trời</div>
          </div>
        </div>
        <div className="top-title">
          <span className="kicker">{lesson.section}</span>
          <h1>{lesson.title}</h1>
        </div>
        <div className="top-actions">
          <button type="button" className="btn btn-icon" onClick={toggleHelp} aria-label="Cách đọc">
            <CircleHelp size={18} />
          </button>
          <button
            type="button"
            className={explain ? "btn on" : "btn"}
            aria-pressed={explain}
            onClick={toggleExplain}
          >
            <BookOpen size={16} />
            Giải thích từng bước
          </button>
        </div>
      </header>

      <nav className="nav" aria-label="Mục lục">
        <div className="nav-scroll">
          {chapters.map((chapter) => (
            <section key={chapter.id} className="chapter-block">
              <h2 className="chapter-label">
                {chapter.num} {chapter.title}
              </h2>
              <div className="lesson-list">
                {chapter.lessonIds.map((id) => {
                  const item = getLesson(id);
                  return (
                    <button
                      key={id}
                      type="button"
                      className={id === lessonId ? "lesson-btn active" : "lesson-btn"}
                      onClick={() => setLesson(id)}
                    >
                      <span className="lesson-idx">{item.section}</span>
                      <span className="lesson-name">{item.title}</span>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </nav>

      <div className="stage-wrap">
        <div className="stage">
          <Stage />
        </div>
        <div className="stage-caption">
          <span>
            Bước {step + 1}/{lesson.steps.length}
            {inspect ? ` · ${inspect}` : ""}
          </span>
          <strong>{current.title}</strong>
        </div>
        {lesson.legend ? (
          <div className="legend">
            {lesson.legend.map((item) => (
              <div key={item.label} className="legend-row">
                <span className={`swatch swatch-${item.swatch}`} />
                {item.label}
              </div>
            ))}
          </div>
        ) : null}
        <ControlDock kinds={lesson.controls ?? []} />
      </div>

      <div className="playback">
        <button type="button" className="btn btn-icon" onClick={prev} aria-label="Bước trước">
          <ChevronLeft size={18} />
        </button>
        <button type="button" className="btn btn-icon" onClick={togglePlay} aria-label={playing ? "Tạm dừng" : "Phát"}>
          {playing ? <Pause size={18} /> : <Play size={18} />}
        </button>
        <button type="button" className="btn btn-icon" onClick={bumpReplay} aria-label="Xem lại bước">
          <RotateCcw size={16} />
        </button>
        <button type="button" className={autoRotate ? "btn on" : "btn"} onClick={toggleRotate}>
          Xoay
        </button>
        <span className="step-count">
          {step + 1}/{lesson.steps.length}
        </span>
        {lesson.steps.length <= 16 ? (
          <div className="dots">
            {lesson.steps.map((s, i) => (
              <button
                key={s.title}
                type="button"
                className={i === step ? "dot on" : i < step ? "dot seen" : "dot"}
                aria-label={s.title}
                onClick={() => setStep(i)}
              />
            ))}
          </div>
        ) : null}
        <button type="button" className="btn btn-icon" onClick={next} aria-label="Bước sau">
          <ChevronRight size={18} />
        </button>
      </div>

      {explain ? (
        <aside className="panel" aria-label="Giải thích">
          <div className="panel-scroll">
            {lesson.id === "glossary" || lesson.id === "refs" ? (
              <input
                className="search"
                value={query}
                placeholder={lesson.id === "glossary" ? "Tìm thuật ngữ" : "Tìm tài liệu"}
                onChange={(e) => useSim.getState().patch({ query: e.target.value })}
              />
            ) : null}
            <span className="kicker">
              Bước {step + 1} · {lesson.section}
            </span>
            <h2>{current.title}</h2>
            <p className="prose">{current.body}</p>
            {current.note ? (
              <div className={`callout ${current.note.kind === "base" ? "" : current.note.kind}`}>
                <span className="call-label">{current.note.title}</span>
                {current.note.text}
              </div>
            ) : null}
            {quizItem ? (
              <div className="quiz">
                {quizItem.options.map((opt, i) => {
                  const picked = quiz[step];
                  const cls =
                    picked === null ? "btn" : i === quizItem.answer ? "btn good" : i === picked ? "btn bad" : "btn";
                  return (
                    <button key={opt} type="button" className={cls} onClick={() => answerQuiz(step, i)}>
                      {opt}
                    </button>
                  );
                })}
                {quiz[step] !== null ? <p className="prose">{quizItem.why}</p> : null}
                <p className="score">
                  Đúng {quizScore}/6
                </p>
              </div>
            ) : null}
            <div className="step-jump">
              {filtered.map(({ s, i }) => (
                <button key={`${s.title}-${i}`} type="button" className={i === step ? "on" : ""} onClick={() => setStep(i)}>
                  <small>
                    {lesson.id === "refs" || lesson.id === "glossary" ? s.title : `Bước ${i + 1}`}
                  </small>
                  {lesson.id === "refs" ? s.body : s.title}
                </button>
              ))}
            </div>
            <p className="footer-note">
              Theo tài liệu tự học Perovskite halide, tháng 10/2026. Đường Shockley–Queisser, biểu đồ hiệu suất và một số chuyển động là minh họa sư phạm, không phải số đo gốc từng điểm.
            </p>
          </div>
        </aside>
      ) : null}

      {help ? (
        <div className="help-layer" onClick={toggleHelp} role="presentation">
          <div
            className="help-card"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-labelledby="help-title"
          >
            <span className="kicker">Cách đọc</span>
            <h2 id="help-title">Phòng thí nghiệm đi cùng tài liệu</h2>
            <ul>
              <li>Mỗi chương là một cụm ở cột trái. Mỗi mục nhỏ có mô hình 3D và một chuỗi bước.</li>
              <li>Nút «Giải thích từng bước» mở hoặc đóng lời dẫn của đúng phần đang xem. Bấm một bước để nhảy tới hình tương ứng.</li>
              <li>Hộp kiến thức nền giải thích từ vựng. Hộp lưu ý là chỗ số liệu cần dè chừng. Hộp giả thuyết là đề xuất chương 5, chưa phải pin đã làm ra.</li>
              <li>Kéo để xoay, cuộn hoặc chụm để phóng. Mũi tên trái phải chuyển bước. Phím E bật giải thích. Phím cách phát hoặc dừng.</li>
              <li>Một số mục có thanh trượt: bước sóng, Voc–Jsc–FF, brom, nhiệt độ, thời gian sống, PLQY, tách lớp.</li>
            </ul>
            <button type="button" className="btn btn-accent" onClick={toggleHelp}>
              Vào thí nghiệm
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function ControlDock({ kinds }: { kinds: ControlKind[] }) {
  const s = useSim();
  if (kinds.length === 0) return null;
  return (
    <div className="dock">
      {kinds.includes("wavelength") ? (
        <label className="ctrl">
          <span>
            Bước sóng <strong>{s.wavelength.toFixed(0)} nm</strong> · E ≈ {photonEnergy(s.wavelength).toFixed(2)} eV
          </span>
          <input
            type="range"
            min={320}
            max={1200}
            value={s.wavelength}
            onChange={(e) => s.patch({ wavelength: Number(e.target.value) })}
          />
          <span className="chip-row">
            <button type="button" className="btn" onClick={() => s.patch({ wavelength: 500 })}>
              Lục 500
            </button>
            <button type="button" className="btn" onClick={() => s.patch({ wavelength: 700 })}>
              Đỏ 700
            </button>
            <button type="button" className="btn" onClick={() => s.patch({ wavelength: 1100 })}>
              IR 1100
            </button>
          </span>
        </label>
      ) : null}
      {kinds.includes("iv") ? (
        <div className="ctrl">
          <span>
            PCE <strong>{pce(s.voc, s.jsc, s.ff).toFixed(1)}%</strong> = {s.voc.toFixed(2)} × {s.jsc.toFixed(1)} × {s.ff.toFixed(2)} / 100
          </span>
          <span>Voc {s.voc.toFixed(2)} V</span>
          <input type="range" min={80} max={135} value={Math.round(s.voc * 100)} onChange={(e) => s.patch({ voc: Number(e.target.value) / 100 })} />
          <span>Jsc {s.jsc.toFixed(1)} mA/cm²</span>
          <input type="range" min={10} max={30} step={0.1} value={s.jsc} onChange={(e) => s.patch({ jsc: Number(e.target.value) })} />
          <span>FF {s.ff.toFixed(2)}</span>
          <input type="range" min={40} max={90} value={Math.round(s.ff * 100)} onChange={(e) => s.patch({ ff: Number(e.target.value) / 100 })} />
          <button type="button" className="btn" onClick={() => s.patch({ voc: 1.19, jsc: 25.8, ff: 0.86 })}>
            Ví dụ 26,4%
          </button>
        </div>
      ) : null}
      {kinds.includes("eg") ? (
        <label className="ctrl">
          <span>
            Eg <strong>{s.eg.toFixed(2)} eV</strong> · trần một lớp minh họa ~{sqEfficiency(s.eg).toFixed(1)}%
          </span>
          <input
            type="range"
            min={50}
            max={300}
            value={Math.round(s.eg * 100)}
            onChange={(e) => s.patch({ eg: Number(e.target.value) / 100 })}
          />
        </label>
      ) : null}
      {kinds.includes("cation") ? (
        <div className="ctrl">
          <span>
            t ≈{" "}
            <strong>
              {tolerance(
                s.mixCs ? ION.fa * 0.95 + ION.cs * 0.05 : s.cation === "Cs" ? ION.cs : s.cation === "MA" ? ION.ma : ION.fa,
              ).toFixed(2)}
            </strong>
          </span>
          <span className="chip-row">
            {(["Cs", "MA", "FA"] as Cation[]).map((c) => (
              <button key={c} type="button" className={s.cation === c && !s.mixCs ? "btn on" : "btn"} onClick={() => s.patch({ cation: c, mixCs: false })}>
                {c}
              </button>
            ))}
            <button type="button" className={s.mixCs ? "btn on" : "btn"} onClick={() => s.patch({ mixCs: true, cation: "FA" })}>
              FA₀.₉₅Cs₀.₀₅
            </button>
          </span>
        </div>
      ) : null}
      {kinds.includes("bromide") ? (
        <label className="ctrl">
          <span>
            Brom <strong>{s.br.toFixed(0)}%</strong> · Eg minh họa {egFromHalide(s.br, s.sn).toFixed(2)} eV
          </span>
          <input type="range" min={0} max={100} value={s.br} onChange={(e) => s.patch({ br: Number(e.target.value) })} />
        </label>
      ) : null}
      {kinds.includes("sn") ? (
        <label className="ctrl">
          <span>
            Thiếc trên vị trí B <strong>{s.sn.toFixed(0)}%</strong>
          </span>
          <input type="range" min={0} max={100} value={s.sn} onChange={(e) => s.patch({ sn: Number(e.target.value) })} />
        </label>
      ) : null}
      {kinds.includes("light") ? (
        <button type="button" className={s.light ? "btn on" : "btn"} onClick={() => s.patch({ light: !s.light })}>
          {s.light ? "Đang chiếu — tắt đèn" : "Chiếu sáng (Hoke)"}
        </button>
      ) : null}
      {kinds.includes("temperature") ? (
        <label className="ctrl">
          <span>
            {phaseFromTemp(s.temp).name} · <strong>{s.temp.toFixed(0)} °C</strong> · {phaseFromTemp(s.temp).en}
          </span>
          <input type="range" min={-150} max={90} value={s.temp} onChange={(e) => s.patch({ temp: Number(e.target.value) })} />
        </label>
      ) : null}
      {kinds.includes("lifetime") ? (
        <div className="ctrl">
          <span>
            τ <strong>{s.tau < 1000 ? `${s.tau.toFixed(0)} ns` : `${(s.tau / 1000).toFixed(1)} µs`}</strong> · L ≈ {diffusionUm(s.tau, s.singleCrystal).toFixed(s.singleCrystal ? 0 : 2)} µm
          </span>
          <input
            type="range"
            min={0}
            max={1000}
            value={Math.round(((Math.log(s.tau) - Math.log(10)) / (Math.log(6e6) - Math.log(10))) * 1000)}
            onChange={(e) => {
              const u = Number(e.target.value) / 1000;
              const tau = Math.exp(Math.log(10) + u * (Math.log(6e6) - Math.log(10)));
              s.patch({ tau });
            }}
          />
          <button type="button" className={s.singleCrystal ? "btn on" : "btn"} onClick={() => s.patch({ singleCrystal: !s.singleCrystal })}>
            {s.singleCrystal ? "Đơn tinh thể" : "Màng mỏng"}
          </button>
        </div>
      ) : null}
      {kinds.includes("plqy") ? (
        <label className="ctrl">
          <span>
            PLQY <strong>{(s.plqy * 100).toFixed(s.plqy < 0.01 ? 3 : 2)}%</strong> · Voc ≈ {vocFromPlqy(s.plqy).toFixed(3)} V
          </span>
          <input
            type="range"
            min={0}
            max={1000}
            value={Math.round(((Math.log(s.plqy) - Math.log(1e-6)) / (0 - Math.log(1e-6))) * 1000)}
            onChange={(e) => {
              const u = Number(e.target.value) / 1000;
              const plqy = Math.exp(Math.log(1e-6) + u * (0 - Math.log(1e-6)));
              s.patch({ plqy });
            }}
          />
        </label>
      ) : null}
      {kinds.includes("enemy") ? (
        <div className="ctrl">
          <span>Kẻ thù và phòng thủ</span>
          <span className="chip-row">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} type="button" className={s.enemy === n ? "btn on" : "btn"} onClick={() => s.patch({ enemy: n })}>
                {n}
              </button>
            ))}
            <button type="button" className={s.defense ? "btn on" : "btn"} onClick={() => s.patch({ defense: !s.defense })}>
              Phòng thủ
            </button>
          </span>
        </div>
      ) : null}
      {kinds.includes("explode") ? (
        <label className="ctrl">
          <span>
            Tách lớp <strong>{Math.round(s.explode * 100)}%</strong>
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(s.explode * 100)}
            onChange={(e) => s.patch({ explode: Number(e.target.value) / 100 })}
          />
        </label>
      ) : null}
      {kinds.includes("nwell") ? (
        <div className="ctrl">
          <span>Số lớp vô cơ n</span>
          <span className="chip-row">
            {[1, 2, 3, 4, 99].map((n) => (
              <button key={n} type="button" className={s.nWell === n ? "btn on" : "btn"} onClick={() => s.patch({ nWell: n })}>
                {n === 99 ? "3D" : `n=${n}`}
              </button>
            ))}
          </span>
        </div>
      ) : null}
      {kinds.includes("architecture") ? (
        <div className="chip-row">
          <button type="button" className={s.architecture === "nip" ? "btn on" : "btn"} onClick={() => s.patch({ architecture: "nip" })}>
            n-i-p
          </button>
          <button type="button" className={s.architecture === "pin" ? "btn on" : "btn"} onClick={() => s.patch({ architecture: "pin" })}>
            p-i-n
          </button>
        </div>
      ) : null}
    </div>
  );
}
