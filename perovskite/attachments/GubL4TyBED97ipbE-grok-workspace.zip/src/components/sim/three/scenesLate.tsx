import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { QUIZ, REFS } from "@/lib/sim/content";
import { diffusionUm, egHex, vocFromPlqy } from "@/lib/sim/physics";
import { useSim } from "@/lib/sim/store";
import { FlowDots, Ion, Molecule, OctaMesh, Pop, Slab, Tag, UnitCell } from "./kit";
import { PlotFrame, Polyline } from "./plot";

const RACE_SINGLE: [number, number][] = [
  [2009, 3.8],
  [2012, 10],
  [2013, 16],
  [2016, 22],
  [2019, 25.2],
  [2023, 26.1],
  [2026, 27.3],
];
const RACE_TANDEM: [number, number][] = [
  [2016, 18],
  [2019, 26],
  [2022, 31],
  [2024, 33.5],
  [2026, 35],
];

function RaceScene({ step }: { step: number }) {
  return (
    <PlotFrame x0={2009} x1={2026} y0={0} y1={40} xLabel="năm" yLabel="%" w={6.4}>
      {(map) => (
        <group>
          <Polyline pts={RACE_SINGLE.map(([x, y]) => map(x, y))} color="#e08a55" />
          {step >= 2 ? <Polyline pts={RACE_TANDEM.map(([x, y]) => map(x, y))} color="#79b0ff" /> : null}
          <Polyline pts={[map(2009, 33.7), map(2026, 33.7)]} color="#8fd0a8" radius={0.015} />
          <Tag position={map(2012, 36)}>SQ 33,7%</Tag>
          <Tag position={map(2018, 3.8)}>{step === 0 ? "3,8% · 2009" : "một lớp"}</Tag>
          {step >= 2 ? <Tag position={map(2024, 35)}>tandem 35%</Tag> : null}
          <Tag position={map(2026, 27.3)} accent>
            27,3%
          </Tag>
        </group>
      )}
    </PlotFrame>
  );
}

function AbsorbScene({ step }: { step: number }) {
  return (
    <group>
      <Slab position={[0, 0, 0]} size={[2.2, 1.5, 1.2]} color="#2a2140" opacity={0.85} />
      <Tag position={[1.6, 0.8, 0]}>500 nm</Tag>
      <FlowDots count={3} color="#79b0ff" speed={0.35} path={(t) => [-0.5, 1.3 - t * 1.1, 0.3]} />
      {step >= 1 ? (
        <FlowDots count={3} color="#e08a55" speed={0.28} path={(t) => [0.15, 1.3 - t * 2.2, 0.2]} />
      ) : null}
      {step >= 1 ? (
        <FlowDots count={2} color="#7a3030" speed={0.22} path={(t) => [0.7, 1.4 - t * 2.8, 0.1]} />
      ) : null}
      {step >= 2 ? (
        <Pop>
          <group position={[2.4, 0, 0]}>
            <Slab position={[0, -0.4, 0]} size={[0.7, 0.9, 0.15]} color="#1e2832" />
            <Slab position={[0, 0.15, 0]} size={[0.7, 0.08, 0.2]} color="#e4a23a" emissive={0.6} />
            <Tag position={[0, 0.85, 0]}>bờ Urbach dốc</Tag>
          </group>
        </Pop>
      ) : null}
    </group>
  );
}

function Walkers({ span }: { span: number }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const pos = useMemo(
    () =>
      Array.from({ length: 28 }, () => new THREE.Vector3((Math.random() - 0.5) * span, (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.6)),
    [span],
  );
  useFrame((_, dt) => {
    const mesh = ref.current;
    if (!mesh) return;
    const hop = Math.sqrt(Math.min(dt, 0.05)) * 0.22;
    pos.forEach((p, i) => {
      p.x = THREE.MathUtils.clamp(p.x + (Math.random() - 0.5) * hop, -span / 2, span / 2);
      p.y = THREE.MathUtils.clamp(p.y + (Math.random() - 0.5) * hop, -0.2, 0.2);
      p.z = THREE.MathUtils.clamp(p.z + (Math.random() - 0.5) * hop, -0.35, 0.35);
      dummy.position.copy(p);
      dummy.scale.setScalar(0.05);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, pos.length]}>
      <sphereGeometry args={[1, 10, 8]} />
      <meshStandardMaterial color="#79b0ff" emissive="#79b0ff" emissiveIntensity={0.5} />
    </instancedMesh>
  );
}

function DiffusionScene({ step }: { step: number }) {
  const tau = useSim((s) => s.tau);
  const single = useSim((s) => s.singleCrystal);
  const L = diffusionUm(tau, single);
  const radius = Math.min(2.6, Math.max(0.2, L));
  return (
    <group>
      <Slab position={[0, 0, 0]} size={[1.6, 0.5, 0.9]} color="#3a2a55" opacity={0.9} />
      <Tag position={[0, -0.7, 0]}>màng 0,5 µm</Tag>
      {step >= 1 ? (
        <mesh>
          <sphereGeometry args={[radius, 28, 18]} />
          <meshBasicMaterial color="#e4a23a" wireframe transparent opacity={0.45} />
        </mesh>
      ) : null}
      <Walkers span={1.4} />
      <Tag position={[0, 1.7, 0]} accent>
        L ≈ {L < 10 ? L.toFixed(2) : L.toFixed(0)} µm
      </Tag>
      {step >= 2 ? <Tag position={[2.1, 0.4, 0]}>2013 · L hơn 1 µm</Tag> : null}
    </group>
  );
}

function ExcitonScene({ step }: { step: number }) {
  const pair = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!pair.current) return;
    const bound = step === 0 || step >= 2;
    const amp = bound ? 0.18 : 0.85 + Math.sin(clock.elapsedTime * 2) * 0.15;
    pair.current.children[0]?.position.set(-amp, 0, 0);
    pair.current.children[1]?.position.set(amp, 0, 0);
  });
  return (
    <group>
      <group ref={pair}>
        <Ion position={[-0.2, 0, 0]} color="#79b0ff" radius={0.18} label="e⁻" />
        <Ion position={[0.2, 0, 0]} color="#e08a55" radius={0.18} label="h⁺" />
      </group>
      <Tag position={[0, 1.3, 0]} accent>
        {step === 0 ? "exciton" : step === 1 ? "kT ≈ 26 meV thắng vài meV" : "hữu cơ: hàng trăm meV"}
      </Tag>
      {step >= 2 ? (
        <Pop>
          <group position={[0, -1.2, 0]}>
            <Slab position={[-0.6, 0, 0]} size={[0.7, 0.35, 0.5]} color="#4d86d6" />
            <Slab position={[0.6, 0, 0]} size={[0.7, 0.35, 0.5]} color="#c46a45" />
            <Tag position={[0, 0.55, 0]}>bulk heterojunction</Tag>
          </group>
        </Pop>
      ) : null}
    </group>
  );
}

function DefectsScene({ step }: { step: number }) {
  return (
    <group>
      <UnitCell a="#3cba84" b="#c5ccd6" x="#6d4bd6" ghost={step === 0} />
      {step === 0 ? (
        <group>
          <Tag position={[-1.6, 1.4, 0]}>chỗ trống</Tag>
          <Tag position={[0, 1.6, 0]}>chen khe</Tag>
          <Tag position={[1.6, 1.4, 0]}>sai chỗ</Tag>
        </group>
      ) : null}
      {step === 1 ? (
        <group>
          <mesh position={[0, 0.15, 1.1]}>
            <sphereGeometry args={[0.12, 14, 12]} />
            <meshStandardMaterial color="#e08a55" emissive="#e08a55" emissiveIntensity={0.8} />
          </mesh>
          <Tag position={[0, 0.7, 1.2]} accent>
            bẫy sâu nuốt điện tử
          </Tag>
        </group>
      ) : null}
      {step >= 2 ? (
        <group>
          <mesh position={[0.9, 0.85, 0.9]}>
            <sphereGeometry args={[0.1, 14, 12]} />
            <meshStandardMaterial color="#8fd0a8" emissive="#8fd0a8" emissiveIntensity={0.7} />
          </mesh>
          <Tag position={[0.2, 1.45, 0]}>bẫy nông · nhiệt thả ra</Tag>
        </group>
      ) : null}
      {step >= 3 ? (
        <Pop>
          {[-0.8, 0, 0.8].map((x) => (
            <mesh key={x} position={[x, 1.05, 0.2]}>
              <sphereGeometry args={[0.08, 12, 10]} />
              <meshStandardMaterial color="#e6c15a" />
            </mesh>
          ))}
          <Tag position={[0, -1.6, 0]}>thụ động hóa bề mặt</Tag>
        </Pop>
      ) : null}
    </group>
  );
}

function TuneScene(_props: { step: number }) {
  const eg = useSim((s) => s.eg);
  const color = egHex(eg);
  const uses = [
    { eg: 1.25, label: "đáy tandem" },
    { eg: 1.53, label: "một lớp" },
    { eg: 1.7, label: "nóctandem" },
    { eg: 2.3, label: "LED / Br" },
  ];
  return (
    <group>
      <OctaMesh color={color} scale={1.25} />
      <Ion position={[0, 0, 0]} color="#c5ccd6" radius={0.24} />
      <Tag position={[0, 1.7, 0]} accent>
        Eg {eg.toFixed(2)} eV
      </Tag>
      {uses.map((u, i) => (
        <Tag key={u.label} position={[-1.8 + i * 1.2, -1.4, 0]} accent={Math.abs(eg - u.eg) < 0.12}>
          {u.label}
        </Tag>
      ))}
    </group>
  );
}

function InkScene({ step }: { step: number }) {
  const drop = useRef<THREE.Mesh>(null);
  const film = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    const t = (clock.elapsedTime % 3) / 3;
    if (drop.current) drop.current.position.y = 1.3 - t * 1.1;
    if (film.current) {
      const mat = film.current.material as THREE.MeshStandardMaterial;
      const k = Math.min(1, Math.max(0, (t - 0.55) / 0.4));
      mat.color.set(k > 0.4 ? "#2a2140" : "#e6c15a");
    }
  });
  return (
    <group>
      <mesh position={[-1.6, 0.55, 0]}>
        <cylinderGeometry args={[0.38, 0.32, 0.7, 20]} />
        <meshStandardMaterial color="#9ec9ea" transparent opacity={0.45} />
      </mesh>
      <mesh ref={drop} position={[-0.2, 1.1, 0]}>
        <sphereGeometry args={[0.1, 14, 12]} />
        <meshStandardMaterial color="#e6c15a" />
      </mesh>
      <mesh ref={film} position={[0.4, -0.35, 0]} rotation={[-0.4, 0.2, 0]}>
        <boxGeometry args={[1.4, 0.06, 1]} />
        <meshStandardMaterial color="#e6c15a" />
      </mesh>
      <Tag position={[0.4, 0.15, 0]}>{step === 0 ? "mực 100–150 °C" : step === 1 ? "lò silicon" : "kính · nhựa · silicon"}</Tag>
      {step >= 1 ? (
        <Pop>
          <Slab position={[2, 0.2, 0]} size={[0.9, 0.9, 0.9]} color="#e08a55" emissive={0.55} />
          <Tag position={[2, 1, 0]}>1400 °C</Tag>
        </Pop>
      ) : null}
      {step >= 2 ? (
        <Pop>
          <group position={[0, -1.3, 0.4]}>
            <Slab position={[-1, 0, 0]} size={[0.7, 0.08, 0.5]} color="#d5e2ea" />
            <mesh position={[0, 0.05, 0]} rotation={[0, 0, 0.4]}>
              <boxGeometry args={[0.7, 0.04, 0.5]} />
              <meshStandardMaterial color="#3cba84" />
            </mesh>
            <Slab position={[1, 0, 0]} size={[0.7, 0.2, 0.5]} color="#b7c3ce" />
          </group>
        </Pop>
      ) : null}
    </group>
  );
}

function PlqyScene(_props: { step: number }) {
  const plqy = useSim((s) => s.plqy);
  const voc = vocFromPlqy(plqy);
  const glow = Math.min(1.4, 0.15 + Math.sqrt(plqy) * 1.3);
  return (
    <group>
      <Slab position={[0, 0, 0]} size={[1.8, 0.22, 1.2]} color="#2a2140" />
      <mesh position={[0, 0.35, 0]}>
        <sphereGeometry args={[0.34, 22, 16]} />
        <meshStandardMaterial color="#e4a23a" emissive="#e4a23a" emissiveIntensity={glow} transparent opacity={0.85} />
      </mesh>
      <Tag position={[0, 1.15, 0]} accent>
        Voc ≈ {voc.toFixed(3)} V
      </Tag>
      <Tag position={[0, -0.7, 0]}>PLQY {(plqy * 100).toFixed(plqy < 0.01 ? 3 : 2)}%</Tag>
    </group>
  );
}

const TECHS = [
  { name: "Silicon", h: 2.75, color: "#b7c3ce", note: "dày, 1400 °C" },
  { name: "CdTe", h: 2.3, color: "#3cba84", note: "Cd" },
  { name: "OPV", h: 2.0, color: "#79b0ff", note: "<150 °C" },
  { name: "Perovskite", h: 3.15, color: "#6d4bd6", note: "27,3% / 35%" },
];

function CompareScene({ step }: { step: number }) {
  return (
    <group>
      {TECHS.map((t, i) => (
        <group key={t.name} position={[-2.25 + i * 1.5, -1.2, 0]}>
          <Slab position={[0, t.h / 2, 0]} size={[0.85, t.h, 0.85]} color={t.color} emissive={i === 3 ? 0.2 : 0} />
          <Tag position={[0, t.h + 0.35, 0]}>{t.name}</Tag>
          {step >= 1 ? <Tag position={[0, -0.35, 0]}>{t.note}</Tag> : null}
        </group>
      ))}
    </group>
  );
}

function EnemiesScene({ step }: { step: number }) {
  const enemy = useSim((s) => s.enemy);
  const defense = useSim((s) => s.defense);
  const which = step >= 5 ? enemy : step + 1;
  const grains = [-0.7, 0.15, 0.95];
  return (
    <group>
      {grains.map((x) => (
        <Slab
          key={x}
          position={[x, 0, 0]}
          size={[0.7, 0.45, 0.8]}
          color={which === 1 && !defense ? "#e6c15a" : "#3a2a55"}
        />
      ))}
      {which === 1 ? (
        <FlowDots count={6} color="#79b0ff" speed={defense ? 0.05 : 0.3} path={(t) => [-1.4 + t * (defense ? 0.4 : 2.6), 0.7 - t * 0.5, 0.4]} />
      ) : null}
      {which === 2 ? (
        <group>
          <Molecule position={[0, 0.8, 0.4]} color="#e15b4c" scale={0.7} />
          <Tag position={[0, 1.3, 0]}>O₂ + ánh sáng</Tag>
        </group>
      ) : null}
      {which === 3 ? (
        <group>
          <Molecule position={[0, defense ? 0.45 : 1.1, 0]} color="#3cba84" />
          <Tag position={[0, 1.45, 0]}>{defense ? "FA/Cs ở lại" : "MA bay hơi"}</Tag>
        </group>
      ) : null}
      {which === 4 ? (
        <group>
          <Slab position={[0, -0.55, 0]} size={[2.4, 0.12, 1]} color="#d7dde6" />
          <Tag position={[0, -0.9, 0]}>TiO₂ + UV</Tag>
          {!defense ? <Tag position={[0, 0.85, 0]} accent>bẫy sâu</Tag> : null}
        </group>
      ) : null}
      {which === 5 ? (
        <FlowDots
          count={5}
          color="#6d4bd6"
          speed={defense ? 0.04 : 0.25}
          path={(t) => [-0.8 + t * (defense ? 0.3 : 1.8), 0.15, 0.45]}
        />
      ) : null}
      {defense ? (
        <mesh>
          <sphereGeometry args={[1.7, 24, 16]} />
          <meshBasicMaterial color="#9ec9ea" wireframe transparent opacity={0.35} />
        </mesh>
      ) : null}
      <Tag position={[0, -1.45, 0]}>kẻ thù {which}/5 {defense ? "· có phòng thủ" : ""}</Tag>
    </group>
  );
}

function NucleationScene({ step }: { step: number }) {
  return (
    <group>
      <group position={[-1.6, 0, 0]}>
        {[-0.45, 0.05, 0.55].map((x) =>
          [-0.35, 0.25].map((z) => (
            <Slab key={`${x}${z}`} position={[x, 0, z]} size={[0.42, 0.28, 0.42]} color="#3a2a55" />
          )),
        )}
        <Tag position={[0, 1, 0]} accent={step === 1}>
          mầm cùng lúc
        </Tag>
      </group>
      <group position={[1.6, 0, 0]}>
        <Slab position={[-0.4, 0, 0]} size={[0.55, 0.4, 0.5]} color="#3a2a55" />
        <Slab position={[0.45, 0, 0.2]} size={[0.3, 0.18, 0.3]} color="#5a4a78" />
        <mesh position={[0.05, 0.05, -0.15]}>
          <circleGeometry args={[0.16, 16]} />
          <meshBasicMaterial color="#0b0f13" />
        </mesh>
        <Tag position={[0, 1, 0]} accent={step === 2}>
          lỗ kim
        </Tag>
      </group>
      {step === 0 ? <Tag position={[0, -1.3, 0]}>tạo mầm → lớn lên</Tag> : null}
    </group>
  );
}

function FilmsScene({ step }: { step: number }) {
  const spin = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (spin.current && step === 0) spin.current.rotation.y += dt * 2.2;
  });
  if (step === 0) {
    return (
      <group ref={spin}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.3, 0]}>
          <cylinderGeometry args={[1.2, 1.2, 0.08, 40]} />
          <meshStandardMaterial color="#2a2140" />
        </mesh>
        <mesh position={[0, 0.5, 0]}>
          <sphereGeometry args={[0.12, 14, 12]} />
          <meshStandardMaterial color="#9ec9ea" />
        </mesh>
        <Tag position={[0, 1.2, 0]}>quay phủ + dung môi đối</Tag>
      </group>
    );
  }
  if (step === 1) {
    return (
      <group>
        <Slab position={[0, -0.2, 0]} size={[2, 0.12, 1.3]} color="#2a2140" />
        <Tag position={[0, 0.5, 0]}>PbI₂ vàng → đen khi gặp muối hữu cơ</Tag>
        <FlowDots count={8} color="#3cba84" speed={0.3} path={(t) => [-0.8 + (t * 1.6), 1 - t * 1.1, 0]} />
      </group>
    );
  }
  return (
    <group>
      <mesh>
        <boxGeometry args={[2.4, 1.6, 1.6]} />
        <meshBasicMaterial color="#9ec9ea" wireframe transparent opacity={0.4} />
      </mesh>
      <Slab position={[0, -0.55, 0]} size={[1.6, 0.18, 1]} color="#b7c3ce" />
      <FlowDots count={10} color="#c5ccd6" speed={0.25} path={(t) => [(t - 0.5) * 1.2, 0.8 - t * 1.2, 0]} />
      <Tag position={[0, 1.25, 0]}>bay hơi chân không</Tag>
    </group>
  );
}

function GrowScene({ step }: { step: number }) {
  const crystal = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!crystal.current || step !== 0) return;
    const s = 0.3 + (0.7 * (Math.sin(clock.elapsedTime * 0.6) + 1)) / 2;
    crystal.current.scale.setScalar(s);
  });
  if (step === 0) {
    return (
      <group>
        <mesh position={[0, -0.15, 0]}>
          <cylinderGeometry args={[0.7, 0.62, 1.1, 24]} />
          <meshStandardMaterial color="#9ec9ea" transparent opacity={0.35} />
        </mesh>
        <group ref={crystal}>
          <OctaMesh color="#6d4bd6" scale={0.7} />
        </group>
        <Tag position={[0, 1.2, 0]}>nóng lên thì độ tan giảm</Tag>
      </group>
    );
  }
  return (
    <group>
      {Array.from({ length: 7 }).map((_, i) => {
        const nm = 410 + i * 48;
        return (
          <group key={nm} position={[-2.1 + i * 0.7, 0, 0]}>
            <OctaMesh color={i < 2 ? "#6d4bd6" : i < 5 ? "#e07a32" : "#e15b4c"} scale={0.32} />
            <Tag position={[0, 0.7, 0]}>{nm}</Tag>
          </group>
        );
      })}
      <Tag position={[0, -1.1, 0]}>chích nóng · LaMer · 410–700 nm</Tag>
    </group>
  );
}

function ScaleScene({ step }: { step: number }) {
  const web = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (web.current) web.current.position.x = ((clock.elapsedTime * 0.4) % 1) - 0.5;
  });
  if (step === 0) {
    return (
      <group>
        <Slab position={[-1.4, 0, 0]} size={[0.7, 0.08, 0.5]} color="#3a2a55" />
        <Tag position={[-1.4, 0.5, 0]}>0,05 cm²</Tag>
        <Slab position={[0.8, 0, 0]} size={[2.2, 0.08, 1.3]} color="#3a2a55" />
        <mesh position={[1.3, 0.08, 0.2]}>
          <sphereGeometry args={[0.08, 12, 10]} />
          <meshStandardMaterial color="#e08a55" emissive="#e08a55" emissiveIntensity={0.8} />
        </mesh>
        <Tag position={[0.8, 0.7, 0]}>một lỗ kim làm chập cả tấm</Tag>
      </group>
    );
  }
  if (step === 1) {
    return (
      <group>
        <Slab position={[0, -0.3, 0]} size={[3, 0.06, 1.2]} color="#2a2140" />
        <Slab position={[0.2, 0.15, 0]} size={[0.15, 0.4, 1.3]} color="#d7dde6" />
        <Tag position={[0, 0.8, 0]}>dao gạt + dao khí N₂</Tag>
      </group>
    );
  }
  if (step === 2) {
    return (
      <group ref={web}>
        {[-1.2, -0.4, 0.4, 1.2].map((x) => (
          <Slab key={x} position={[x, 0, 0]} size={[0.6, 0.05, 0.8]} color="#3a2a55" />
        ))}
        <Tag position={[0, 0.7, 0]}>cuộn sang cuộn</Tag>
      </group>
    );
  }
  return (
    <group>
      <mesh>
        <boxGeometry args={[2.6, 1.5, 1.5]} />
        <meshBasicMaterial color="#9ec9ea" wireframe />
      </mesh>
      <Tag position={[0, 1.2, 0]}>chân không, phủ đều</Tag>
    </group>
  );
}

function AppsScene({ step }: { step: number }) {
  const titles = [
    "Pin một lớp",
    "Tandem",
    "Dẻo",
    "Màn hình",
    "PeLED",
    "Cảm biến",
    "Tia X",
    "Nhiên liệu",
  ];
  return (
    <group>
      {step === 0 ? <Slab position={[0, 0, 0]} size={[1.8, 0.12, 1.2]} color="#2a2140" /> : null}
      {step === 1 ? (
        <group>
          <Slab position={[0, -0.15, 0]} size={[1.8, 0.25, 1.2]} color="#b7c3ce" />
          <Slab position={[0, 0.15, 0]} size={[1.8, 0.08, 1.2]} color="#6d4bd6" />
        </group>
      ) : null}
      {step === 2 ? (
        <mesh rotation={[0.4, 0.3, 0.5]}>
          <boxGeometry args={[1.8, 0.04, 0.9]} />
          <meshStandardMaterial color="#3cba84" />
        </mesh>
      ) : null}
      {step === 3
        ? [-0.6, 0, 0.6].map((x, i) => (
            <mesh key={x} position={[x, 0, 0]}>
              <boxGeometry args={[0.4, 0.4, 0.08]} />
              <meshStandardMaterial
                color={["#e15b4c", "#8fd0a8", "#4d86d6"][i]}
                emissive={["#e15b4c", "#8fd0a8", "#4d86d6"][i]}
                emissiveIntensity={0.7}
              />
            </mesh>
          ))
        : null}
      {step === 4 ? (
        <mesh>
          <sphereGeometry args={[0.45, 24, 18]} />
          <meshStandardMaterial color="#8fd0a8" emissive="#8fd0a8" emissiveIntensity={1.2} />
        </mesh>
      ) : null}
      {step === 5 ? <Slab position={[0, 0, 0]} size={[1.4, 0.2, 0.8]} color="#1e2832" emissive={0.3} /> : null}
      {step === 6 ? (
        <group>
          <OctaMesh color="#e6c15a" />
          <FlowDots count={2} color="#f4efe6" speed={0.4} path={(t) => [-1.4 + t * 1.5, 0.8 - t * 0.8, 0]} />
        </group>
      ) : null}
      {step === 7 ? (
        <group>
          <Slab position={[-1.1, 0.3, 0]} size={[0.8, 0.1, 0.6]} color="#6d4bd6" />
          <mesh position={[0.7, -0.2, 0]}>
            <cylinderGeometry args={[0.45, 0.45, 0.7, 20]} />
            <meshStandardMaterial color="#79b0ff" transparent opacity={0.35} />
          </mesh>
          <FlowDots count={4} color="#f4efe6" speed={0.2} path={(t) => [0.7, -0.2 + t * 0.6, 0]} />
        </group>
      ) : null}
      <Tag position={[0, 1.35, 0]} accent>
        {titles[step] ?? ""}
      </Tag>
    </group>
  );
}

const MARKET = [
  ["6/2024", "Oxford PV 26,9%"],
  ["4/2025", "LONGi 34,85%"],
  ["7/2025", "Caelux"],
  ["2026", "NREL 27,3 / 35"],
  ["7/2026", "35,5% chưa NREL"],
  ["2035", "dự báo"],
];

function MarketScene({ step }: { step: number }) {
  return (
    <group>
      <mesh position={[0, -0.8, 0]}>
        <boxGeometry args={[6.2, 0.04, 0.04]} />
        <meshStandardMaterial color="#93a0ac" />
      </mesh>
      {MARKET.map((m, i) => (
        <group key={m[0]} position={[-2.6 + i * 1.05, -0.8, 0]}>
          <mesh position={[0, i === step ? 0.45 : 0.2, 0]}>
            <sphereGeometry args={[i === step ? 0.16 : 0.08, 14, 12]} />
            <meshStandardMaterial color={i === step ? "#e4a23a" : "#1e2832"} emissive={i === step ? "#e4a23a" : "#000"} emissiveIntensity={0.6} />
          </mesh>
          {i === step ? (
            <Tag position={[0, 1.05, 0]} accent>
              {m[0]} · {m[1]}
            </Tag>
          ) : (
            <Tag position={[0, 0.55, 0]}>{m[0]}</Tag>
          )}
        </group>
      ))}
    </group>
  );
}

const BARS = [
  { name: "Pb", v: 27.3, color: "#6d4bd6" },
  { name: "Sn–Pb", v: 24, color: "#d2a36a" },
  { name: "Sn", v: 16.65, color: "#e6c15a" },
  { name: "Cs₂AgBiBr₆", v: 6.37, color: "#e08a55" },
];

function LeadScene({ step }: { step: number }) {
  return (
    <group>
      {BARS.map((b, i) => (
        <group key={b.name} position={[0, 1.1 - i * 0.7, 0]}>
          <Slab position={[-2.2 + b.v / 20, 0, 0]} size={[b.v / 10, 0.32, 0.32]} color={b.color} emissive={step === i ? 0.35 : 0.05} />
          <Tag position={[-2.6, 0, 0]}>{b.name}</Tag>
          <Tag position={[b.v / 10 - 1.6, 0.35, 0]} accent={step === i}>
            {b.v}%
          </Tag>
        </group>
      ))}
    </group>
  );
}

function MiniStack({
  nip,
  active,
}: {
  nip: boolean;
  active: boolean;
}) {
  const cols = nip
    ? ["#e0b15a", "#4d86d6", "#2a2140", "#c46a45", "#d5e2ea"]
    : ["#d5e2ea", "#c46a45", "#2a2140", "#4d86d6", "#e0b15a"];
  return (
    <group scale={active ? 1 : 0.82}>
      {cols.map((c, i) => (
        <Slab key={c + i} position={[0, -0.8 + i * 0.32, 0]} size={[1.3, i === 2 ? 0.4 : 0.18, 0.8]} color={c} />
      ))}
      <Tag position={[0, 1.15, 0]}>{nip ? "n-i-p" : "p-i-n"}</Tag>
      <FlowDots count={3} color="#e4a23a" speed={0.2} path={(t) => [0, nip ? 1 - t * 1.6 : -1.1 + t * 1.6, 0.5]} />
    </group>
  );
}

function PinScene({ step }: { step: number }) {
  const architecture = useSim((s) => s.architecture);
  if (step >= 3) {
    return (
      <group>
        <Slab position={[-1.4, 0.4, 0]} size={[1.1, 0.3, 0.5]} color="#4d86d6" />
        <Slab position={[1.4, -0.3, 0]} size={[1.1, 0.3, 0.5]} color="#c46a45" />
        <Tag position={[-1.4, 0.9, 0]}>ETL · điện tử xuống dốc</Tag>
        <Tag position={[1.4, 0.2, 0]}>HTL · lỗ trống</Tag>
        <FlowDots count={4} color="#79b0ff" speed={0.25} path={(t) => [0.4 - t * 1.6, 0.9 - t * 0.5, 0]} />
        <FlowDots count={4} color="#e08a55" speed={0.25} path={(t) => [-0.2 + t * 1.4, 0.2 - t * 0.45, 0]} />
      </group>
    );
  }
  return (
    <group>
      <group position={[-1.5, 0, 0]}>
        <MiniStack nip active={architecture === "nip" || step === 0} />
      </group>
      <group position={[1.5, 0, 0]}>
        <MiniStack nip={false} active={architecture === "pin" || step >= 1} />
      </group>
    </group>
  );
}

const STACK = [
  { name: "Kính UV", color: "#9ec9ea", h: 0.18 },
  { name: "ITO", color: "#d5e2ea", h: 0.07 },
  { name: "NiOx", color: "#6d8f62", h: 0.1 },
  { name: "SAM", color: "#e6c15a", h: 0.04 },
  { name: "2D dưới", color: "#b07adf", h: 0.06 },
  { name: "Lõi FA/Cs", color: "#3a2a55", h: 0.42 },
  { name: "2D trên", color: "#b07adf", h: 0.06 },
  { name: "C60", color: "#8b939e", h: 0.08 },
  { name: "SnO2", color: "#d9d3c8", h: 0.06 },
  { name: "Cu/Ag", color: "#e0b15a", h: 0.12 },
  { name: "Kính kín", color: "#b7daf2", h: 0.18 },
];

function stackFocus(step: number): number[] {
  if (step <= 0) return [];
  if (step === 1) return [0];
  if (step === 2) return [1, 2, 3];
  return [Math.min(STACK.length - 1, step + 1)];
}

function StackScene({ step }: { step: number }) {
  const explode = useSim((s) => s.explode);
  const focus = stackFocus(step);
  const gap = explode * 0.2;
  const total = STACK.reduce((s, l) => s + l.h, 0) + gap * (STACK.length - 1);
  let y = -total / 2;
  const setStep = useSim((s) => s.setStep);
  return (
    <group>
      {STACK.map((layer, i) => {
        const center = y + layer.h / 2;
        y += layer.h + gap;
        const on = focus.includes(i);
        return (
          <group key={layer.name}>
            <Slab
              position={[0, center, 0]}
              size={[1.8, layer.h, 1.15]}
              color={layer.color}
              emissive={on ? 0.45 : 0.05}
              onClick={() => setStep(i === 0 ? 1 : i <= 3 ? 2 : i - 1)}
            />
            {on ? (
              <Tag position={[1.35, center, 0]} accent>
                {layer.name}
              </Tag>
            ) : null}
          </group>
        );
      })}
      <FlowDots count={4} color="#e4a23a" speed={0.18} path={(t) => [0, -1.6 + t * 1.2, 0.7]} />
    </group>
  );
}

function WhyScene({ step }: { step: number }) {
  if (step === 0) {
    return (
      <group>
        <Molecule position={[-0.8, 0.9, 0]} color="#e08a55" />
        <Tag position={[-0.8, 1.5, 0]}>MA bay</Tag>
        <Molecule position={[0.7, 0, 0]} color="#e6c15a" />
        <Ion position={[1.3, 0.1, 0]} color="#79b0ff" radius={0.16} label="Cs" />
        <Tag position={[0.9, -0.7, 0]}>FA + Cs ở lại</Tag>
      </group>
    );
  }
  if (step === 1) {
    return (
      <group>
        <OctaMesh color="#6d4bd6" />
        <Tag position={[0, 1.5, 0]}>thuần iod · không Hoke</Tag>
      </group>
    );
  }
  if (step === 2) {
    return (
      <group>
        <Ion position={[0, 0.2, 0]} color="#e6c15a" radius={0.45} label="FA" />
        <Ion position={[0.7, 0.35, 0]} color="#79b0ff" radius={0.2} label="5% Cs" />
        <Tag position={[0, -0.8, 0]}>kéo t về vùng bền</Tag>
      </group>
    );
  }
  if (step === 3) {
    return (
      <group>
        <Slab position={[0, 0, 0]} size={[1.8, 0.4, 1.1]} color="#3a2a55" />
        <Slab position={[0, 0.32, 0]} size={[1.9, 0.06, 1.2]} color="#b07adf" />
        <Slab position={[0, -0.32, 0]} size={[1.9, 0.06, 1.2]} color="#b07adf" />
        <Tag position={[0, 1, 0]}>2D hai mặt</Tag>
      </group>
    );
  }
  return (
    <group>
      <Slab position={[0, 0.4, 0]} size={[1.8, 0.08, 1.1]} color="#d9d3c8" />
      <Slab position={[0, 0.85, 0]} size={[1.8, 0.12, 1.1]} color="#e0b15a" />
      <FlowDots count={5} color="#6d4bd6" speed={0.2} path={(t) => [(t - 0.5) * 1.2, -0.6 + Math.min(0.85, t * 1.3), 0.3]} />
      <Tag position={[0, -1.1, 0]}>SnO₂ ALD chặn iod</Tag>
    </group>
  );
}

function VerifyScene({ step }: { step: number }) {
  const good = (t: number) => 92 + 8 * Math.exp(-t / 500);
  const bad = (t: number) => 38 + 62 * Math.exp(-t / 420);
  return (
    <PlotFrame x0={0} x1={2500} y0={40} y1={100} xLabel="giờ" yLabel="% còn lại">
      {(map) => {
        const gPts: [number, number, number][] = [];
        const bPts: [number, number, number][] = [];
        for (let i = 0; i <= 24; i++) {
          const t = (i / 24) * 2500;
          gPts.push(map(t, good(t)));
          bPts.push(map(t, bad(t)));
        }
        return (
          <group>
            <Polyline pts={bPts} color="#e08a55" />
            <Polyline pts={gPts} color="#8fd0a8" />
            <mesh position={map(2000, 93)}>
              <sphereGeometry args={[0.09, 12, 10]} />
              <meshStandardMaterial color="#e4a23a" emissive="#e4a23a" emissiveIntensity={0.8} />
            </mesh>
            <Tag position={map(2000, 97)}>93% · 2000 h đã báo cáo</Tag>
            {step >= 1 ? <Tag position={map(400, 48)}>đèn + nhiệt + ẩm</Tag> : null}
            {step >= 6 ? (
              <Tag position={map(1250, 70)} accent>
                giả thuyết
              </Tag>
            ) : null}
          </group>
        );
      }}
    </PlotFrame>
  );
}

const LOOP = ["Cấu trúc", "Tính chất", "Hiệu năng", "Thiết kế lại"];

function FinaleScene({ step }: { step: number }) {
  const active = Math.min(3, step);
  return (
    <group>
      {LOOP.map((name, i) => {
        const ang = (i / 4) * Math.PI * 2 - Math.PI / 2;
        const on = i === active;
        return (
          <group key={name} position={[Math.cos(ang) * 1.8, 0.2, Math.sin(ang) * 1.8]}>
            <mesh>
              <cylinderGeometry args={[0.42, 0.42, 0.18, 20]} />
              <meshStandardMaterial color={on ? "#e4a23a" : "#1e2832"} emissive={on ? "#e4a23a" : "#000"} emissiveIntensity={0.45} />
            </mesh>
            <Tag position={[0, 0.55, 0]} accent={on}>
              {name}
            </Tag>
          </group>
        );
      })}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.8, 0.02, 8, 48]} />
        <meshBasicMaterial color="#93a0ac" />
      </mesh>
      {step >= 4 ? <Tag position={[0, -1.3, 0]}>mạng mềm là cả hai mặt</Tag> : null}
    </group>
  );
}

function QuizScene({ step }: { step: number }) {
  const q = QUIZ[step];
  if (step === 0) {
    return (
      <group>
        <Slab position={[0, 0, 0]} size={[1.6, 0.7, 1]} color="#2a2140" />
        <FlowDots count={1} color="#7a3030" speed={0.15} path={(t) => [0, 1.2 - t * 2.2, 0.4]} />
        <Tag position={[0, 1.3, 0]}>900 nm · 1,38 eV</Tag>
      </group>
    );
  }
  if (step === 1) return <UnitCell aLabel="1/8" bLabel="1" xLabel="1/2" highlight="A" />;
  if (step === 2) {
    return (
      <group>
        <group position={[-1.2, 0, 0]}>
          <OctaMesh color="#e6c15a" scale={0.7} />
          <Tag position={[0, 1.1, 0]}>Cs nhỏ</Tag>
        </group>
        <group position={[1.2, 0, 0]}>
          <OctaMesh color="#e08a55" scale={0.7} />
          <Tag position={[0, 1.1, 0]}>FA lớn</Tag>
        </group>
      </group>
    );
  }
  if (step === 3) {
    return (
      <group>
        <Tag position={[0, 0.4, 0]} accent>
          2 × 60 mV ≈ 120 mV
        </Tag>
        <Tag position={[0, -0.4, 0]}>1% → 0,01%</Tag>
      </group>
    );
  }
  if (step === 4) {
    return (
      <group>
        <Slab position={[0, 0.25, 0]} size={[1.6, 0.1, 1]} color="#6d4bd6" />
        <Slab position={[0, -0.15, 0]} size={[1.6, 0.28, 1]} color="#b7c3ce" />
        <Tag position={[0, 0.8, 0]}>hai Eg, một nắng</Tag>
      </group>
    );
  }
  return (
    <group>
      <Slab position={[0, 0, 0]} size={[1.7, 0.35, 1]} color="#3a2a55" />
      <Slab position={[0, 0.28, 0]} size={[1.8, 0.06, 1.1]} color="#b07adf" />
      <Slab position={[0, 0.5, 0]} size={[1.8, 0.08, 1.1]} color="#d9d3c8" />
      <Tag position={[0, 1.1, 0]}>{q ? "2D + SnO₂" : ""}</Tag>
    </group>
  );
}

function RefsScene({ step }: { step: number }) {
  const safe = ((step % REFS.length) + REFS.length) % REFS.length;
  return (
    <group>
      {REFS.map((r, i) => {
        const ang = ((i - safe) / REFS.length) * Math.PI * 2;
        const active = i === safe;
        return (
          <mesh
            key={r.n}
            position={[Math.sin(ang) * 2.6, active ? 0.4 : -0.2, Math.cos(ang) * 2.6]}
            scale={active ? 1.35 : 0.55}
          >
            <boxGeometry args={[0.42, 0.62, 0.08]} />
            <meshStandardMaterial color={active ? "#e4a23a" : "#24303a"} />
          </mesh>
        );
      })}
      <Tag position={[0, 1.45, 0]} accent>
        [{REFS[safe]?.n}] {REFS[safe]?.cite.slice(0, 48)}
      </Tag>
    </group>
  );
}

export const lateScenes = {
  race: RaceScene,
  absorb: AbsorbScene,
  diffusion: DiffusionScene,
  exciton: ExcitonScene,
  defects: DefectsScene,
  tune: TuneScene,
  ink: InkScene,
  plqy: PlqyScene,
  compare: CompareScene,
  enemies: EnemiesScene,
  nucleation: NucleationScene,
  films: FilmsScene,
  grow: GrowScene,
  scale: ScaleScene,
  apps: AppsScene,
  market: MarketScene,
  lead: LeadScene,
  pin: PinScene,
  stack: StackScene,
  why: WhyScene,
  verify: VerifyScene,
  finale: FinaleScene,
  quiz: QuizScene,
  refs: RefsScene,
};
